import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
from solution.data import ROOT, complete_panel, load_data
from solution.features import FEATURES, FeatureBuilder
from solution.model import load_models, predict, predict_members
from solution.pipeline import REFERENCE_SHA256, export_submission, rounded


class ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.panel, cls.calendar = load_data()
        cls.builder = FeatureBuilder(cls.panel, cls.calendar)

    def test_exact_submission_after_native_reload(self):
        first = predict(self.builder, ROOT / "models")
        second = predict(self.builder, ROOT / "models")
        np.testing.assert_array_equal(first.prediction_raw, second.prediction_raw)
        with tempfile.TemporaryDirectory() as temp:
            report = export_submission(first, Path(temp) / "submission.csv")
        self.assertEqual(report["sha256"], REFERENCE_SHA256)
        self.assertEqual(report["rows"], 14640)

    def test_future_poison_does_not_change_training_or_forecast_features(self):
        origin = "2025-09-01"
        changed = self.panel.copy()
        changed.loc[changed.date >= origin, "boardings"] = 1e12
        poisoned = FeatureBuilder(changed, self.calendar)
        for first, second in [
            (self.builder.train(origin), poisoned.train(origin)),
            (self.builder.forecast(origin), poisoned.forecast(origin)),
        ]:
            pd.testing.assert_frame_equal(
                first[FEATURES], second[FEATURES], check_exact=True
            )
        pd.testing.assert_series_equal(
            self.builder.train(origin).boardings, poisoned.train(origin).boardings
        )
        _, models = load_models(ROOT / "models")
        a = predict_members(
            models, self.builder.forecast(origin), self.builder.zero_routes(origin)
        )
        b = predict_members(
            models, poisoned.forecast(origin), poisoned.zero_routes(origin)
        )
        np.testing.assert_array_equal(a, b)

    def test_target_slices_keep_every_route_and_precede_cutoff(self):
        training = self.builder.train("2025-11-01")
        self.assertEqual(len(training), 59760)
        self.assertTrue(
            training.groupby(["origin", "date", "hour"]).route.nunique().eq(10).all()
        )
        self.assertTrue((training.history_end < training.origin).all())
        self.assertTrue((training.date < "2025-11-01").all())

    def test_missing_and_duplicate_rows_rejected(self):
        observed = self.panel.loc[
            ~self.panel.implicit_zero, ["date", "route", "hour", "boardings"]
        ]
        bad = observed.copy()
        bad.loc[bad.index[0], "boardings"] = np.nan
        with self.assertRaises(ValueError):
            complete_panel(bad)
        with self.assertRaises(ValueError):
            complete_panel(pd.concat([observed, observed.iloc[[0]]]))
        for corrupted in (
            self.panel.iloc[1:],
            pd.concat([self.panel, self.panel.iloc[[0]]]),
        ):
            with self.assertRaises(ValueError):
                FeatureBuilder(corrupted, self.calendar)
        self.assertEqual(int(complete_panel(observed).implicit_zero.sum()), 15409)

    def test_zero_rule_uses_history_and_rounding_occurs_once(self):
        changed = self.panel.copy()
        changed.loc[changed.route == 1, "boardings"] = 0
        changed.loc[changed.route == 5, "boardings"] = 1
        zeros = FeatureBuilder(changed, self.calendar).zero_routes("2025-11-01")
        self.assertIn("1", zeros)
        self.assertNotIn("5", zeros)
        self.assertEqual(rounded([0.5, 1.5, 2.5, 3.5]).tolist(), [0, 2, 2, 4])


if __name__ == "__main__":
    unittest.main()
