"""Fixed five-seed MAE recipe, native CatBoost artifacts, unrounded ensemble inference."""

import json
import platform
import time
from importlib.metadata import version
from pathlib import Path

import numpy as np
from catboost import CatBoostRegressor

from .data import ROOT, sha256, verify_data, write_json
from .features import FEATURES

SEEDS = [42, 17, 123, 2025, 2026]
PARAMETERS = {
    "iterations": 450,
    "depth": 6,
    "learning_rate": 0.04,
    "l2_leaf_reg": 8,
    "loss_function": "MAE",
}


def environment():
    return {
        "python": platform.python_version(),
        **{n: version(n) for n in ("numpy", "pandas", "catboost")},
    }


def predict_members(models, frame, zero_routes, threads=4):
    if not 1 <= threads <= 4:
        raise ValueError("Use between one and four CPU threads")
    prediction = np.zeros(len(frame), dtype=float)
    for weight, estimator in models:
        member = np.maximum(estimator.predict(frame[FEATURES], thread_count=threads), 0)
        member[frame.route.isin(zero_routes).to_numpy()] = 0
        prediction += weight * member
    if not np.isfinite(prediction).all():
        raise ValueError("Non-finite predictions")
    return prediction


def train(builder, origin, output, threads=4, root=ROOT):
    if not 1 <= threads <= 4:
        raise ValueError("Use between one and four CPU threads")
    output = Path(output).resolve()
    # Keep the submitted weights immutable during Run All / accidental re-runs.
    if output == (Path(root) / "models").resolve() or output.exists():
        raise ValueError(
            "Choose a new output directory; existing artifacts are never overwritten"
        )
    frame = builder.train(origin)
    target = frame.boardings.to_numpy(dtype=float)
    output.mkdir(parents=True)
    started = time.perf_counter()
    entries = []
    for seed in SEEDS:
        estimator = CatBoostRegressor(
            **PARAMETERS,
            random_seed=seed,
            thread_count=threads,
            verbose=False,
            allow_writing_files=False,
        )
        estimator.fit(frame[FEATURES], target, cat_features=["route"])
        filename = f"catboost_seed_{seed}.cbm"
        estimator.save_model(str(output / filename))
        entries.append(
            {
                "seed": seed,
                "weight": 0.2,
                "file": filename,
                "sha256": sha256(output / filename),
            }
        )
    manifest = {
        "format": "moscowt-catboost-61d-v1",
        "origin": str(origin),
        "horizon_days": 61,
        "features": FEATURES,
        "parameters": PARAMETERS,
        "seeds": SEEDS,
        "entries": entries,
        "zero_routes": builder.zero_routes(origin),
        "training_rows": len(frame),
        "threads": threads,
        "environment": environment(),
        "fit_seconds": time.perf_counter() - started,
        "data_manifest_sha256": sha256(Path(root) / "data/manifest.json"),
        "input_hashes": {x["path"]: x["sha256"] for x in verify_data(root)["files"]},
        "status": "retrained; no competition score assigned",
        "training_policy": "sparse14; all targets strictly before origin; MAE; no sample weights",
    }
    write_json(output / "manifest.json", manifest)
    return manifest


def load_models(folder, root=ROOT):
    folder = Path(folder)
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    if (
        manifest["format"] != "moscowt-catboost-61d-v1"
        or manifest["features"] != FEATURES
        or manifest["parameters"] != PARAMETERS
        or manifest["seeds"] != SEEDS
        or len(manifest["entries"]) != 5
        or manifest["horizon_days"] != 61
    ):
        raise ValueError("Unsupported model schema or recipe")
    if manifest["data_manifest_sha256"] != sha256(Path(root) / "data/manifest.json"):
        raise ValueError("Model and input manifest do not match")
    models = []
    for seed, entry in zip(SEEDS, manifest["entries"], strict=True):
        if (
            entry["file"] != f"catboost_seed_{seed}.cbm"
            or entry["seed"] != seed
            or entry["weight"] != 0.2
        ):
            raise ValueError("Invalid ensemble member")
        path = folder / entry["file"]
        if sha256(path) != entry["sha256"]:
            raise ValueError(f"Model checksum mismatch: {entry['file']}")
        estimator = CatBoostRegressor().load_model(str(path))
        if (
            estimator.feature_names_ != FEATURES
            or estimator.get_cat_feature_indices() != [0]
        ):
            raise ValueError("Native CatBoost schema mismatch")
        models.append((entry["weight"], estimator))
    return manifest, models


def predict(builder, folder, threads=4, root=ROOT):
    manifest, models = load_models(folder, root)
    if sorted(builder.zero_routes(manifest["origin"])) != sorted(
        manifest["zero_routes"]
    ):
        raise ValueError("Zero-history routes do not match model metadata")
    frame = builder.forecast(manifest["origin"])
    result = frame[["origin", "date", "route", "hour", "horizon_days"]].copy()
    result["prediction_raw"] = predict_members(
        models, frame, manifest["zero_routes"], threads
    )
    return result
