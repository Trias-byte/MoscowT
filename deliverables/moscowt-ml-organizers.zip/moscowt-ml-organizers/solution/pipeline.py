"""Portable CSV export and leakage-free 61-day validation."""

from pathlib import Path

import numpy as np
import pandas as pd

from .data import ROOT, load_data, sha256, write_json
from .features import FeatureBuilder
from .model import predict, train

REFERENCE_SHA256 = "4adcc1b06ccd53eeddee5637560919396483809fc2da696cae3c1cba013a8d95"


def builder(root=ROOT):
    return FeatureBuilder(*load_data(root))


def rounded(values):
    values = np.asarray(values, dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Invalid prediction")
    return np.rint(np.maximum(values, 0)).astype("int64")


def export_submission(prediction, output, root=ROOT):
    template = pd.read_csv(
        Path(root) / "data/test_submission.csv", sep=";", dtype={"route": str}
    )
    keys = ["route", "date", "hour"]
    template = template[keys]
    values = prediction.assign(date=prediction.date.dt.strftime("%Y-%m-%d"))
    result = template.merge(
        values[keys + ["prediction_raw"]], on=keys, how="left", validate="one_to_one"
    )
    if (
        len(result) != 14640
        or len(values) != 14640
        or result.prediction_raw.isna().any()
    ):
        raise ValueError("Forecast must cover exactly all 14,640 competition keys")
    result["prediction"] = rounded(result.pop("prediction_raw"))
    output = Path(output).resolve()
    if output == (Path(root) / "reference/submission.csv").resolve():
        raise ValueError("The reference submission is immutable")
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, sep=";", index=False, encoding="utf-8", lineterminator="\n")
    checksum = sha256(output)
    report = {
        "rows": len(result),
        "total": int(result.prediction.sum()),
        "sha256": checksum,
        "matches_reference": checksum == REFERENCE_SHA256,
        "rounding": "half-even, once after averaging",
    }
    write_json(output.with_suffix(".manifest.json"), report)
    return report


def metrics(truth, predictions):
    truth = np.asarray(truth, dtype=float)
    value = rounded(predictions)
    total = float(truth.sum())
    error = float(np.abs(truth - value).sum())
    return {
        "rows": len(truth),
        "target_sum": total,
        "absolute_error": error,
        "wape": error / total if total else None,
        "score": max(0.0, 1 - error / total) if total else None,
        "mae": float(np.abs(truth - value).mean()),
        "bias": float((value - truth).mean()),
    }


def backtest(origin, output, threads=4, root=ROOT):
    output = Path(output)
    feature_builder = builder(root)
    cutoff = pd.Timestamp(origin)
    if cutoff + pd.Timedelta(days=61) > pd.Timestamp("2025-11-01"):
        raise ValueError(
            "The 61-day evaluation needs known truth strictly before November"
        )
    model = train(feature_builder, origin, output / "models", threads, root)
    predicted = predict(feature_builder, output / "models", threads, root)
    target = feature_builder.forecast(origin)
    if not predicted[["date", "route", "hour"]].equals(
        target[["date", "route", "hour"]]
    ):
        raise AssertionError("Validation keys differ")
    report = {
        "origin": origin,
        "horizon_days": 61,
        "model": model["parameters"],
        "metrics": metrics(target.boardings, predicted.prediction_raw),
        "slices": {},
    }
    for name, mask in [
        ("days_1_7", target.horizon_days <= 7),
        ("days_8_28", target.horizon_days.between(8, 28)),
        ("days_29_61", target.horizon_days >= 29),
    ]:
        report["slices"][name] = metrics(
            target.boardings[mask], predicted.prediction_raw[mask]
        )
    predicted.assign(
        truth=target.boardings, prediction=rounded(predicted.prediction_raw)
    ).to_csv(output / "predictions.csv", index=False)
    write_json(output / "metrics.json", report)
    return report
