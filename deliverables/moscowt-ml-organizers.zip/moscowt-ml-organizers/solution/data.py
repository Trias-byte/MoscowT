"""Strict loading of the organizers' complete, aggregated 2025 extract."""

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
ROUTES = [1, 5, 7, 11, 12, 17, 25, 26, 28, 50]
START = pd.Timestamp("2025-01-01")
CUTOFF = pd.Timestamp("2025-11-01")
KEYS = ["date", "route", "hour"]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def verify_data(root=ROOT):
    manifest = json.loads((root / "data/manifest.json").read_text(encoding="utf-8"))
    for entry in manifest["files"]:
        if sha256(root / entry["path"]) != entry["sha256"]:
            raise ValueError(f"Input checksum mismatch: {entry['path']}")
    return manifest


def complete_panel(observed):
    """Zero-fill omitted keys only for this specific, complete official extract."""
    if observed.isna().any().any() or not np.isfinite(observed.boardings).all():
        raise ValueError("Explicit missing or non-finite observations are not zeros")
    if observed.duplicated(KEYS).any() or (observed.boardings < 0).any():
        raise ValueError("Duplicate keys or negative observations")
    if not observed.route.isin(ROUTES).all() or not observed.hour.isin(range(24)).all():
        raise ValueError("Unexpected route or hour")
    if not observed.date.between(START, CUTOFF, inclusive="left").all():
        raise ValueError("Observations outside January–October 2025")
    expected = pd.MultiIndex.from_product(
        [pd.date_range(START, CUTOFF, inclusive="left"), ROUTES, range(24)], names=KEYS
    ).to_frame(index=False)
    panel = expected.merge(
        observed, on=KEYS, how="left", validate="one_to_one", indicator=True
    )
    panel["implicit_zero"] = panel.pop("_merge").eq("left_only")
    panel["boardings"] = panel.boardings.fillna(0).astype("float64")
    return panel


def load_data(root=ROOT):
    root = Path(root)
    verify_data(root)
    observed = pd.concat(
        [
            pd.read_csv(
                root / "data" / f"labels_day_{part}.csv", sep=";", parse_dates=["date"]
            )
            for part in ("train", "test")
        ],
        ignore_index=True,
    )
    panel = complete_panel(observed)
    if (
        len(panel) != 72960
        or panel.boardings.sum() != 59667191
        or panel.implicit_zero.sum() != 15409
    ):
        raise ValueError("Official history audit failed")
    cal = pd.read_csv(root / "data/calendar_2025.csv", parse_dates=["date"])
    if cal.isna().any().any() or cal.date.duplicated().any():
        raise ValueError("Incomplete calendar")
    # Evaluate cycles identically to the original generator before float32 conversion.
    day = pd.DatetimeIndex(cal.date).dayofyear
    cal["year_sin"] = np.sin(2 * np.pi * (day - 1) / 365)
    cal["year_cos"] = np.cos(2 * np.pi * (day - 1) / 365)
    return panel, cal


def audit(root=ROOT):
    panel, cal = load_data(root)
    return {
        "rows": len(panel),
        "target_sum": int(panel.boardings.sum()),
        "implicit_zero_rows": int(panel.implicit_zero.sum()),
        "calendar_days": len(cal),
        "routes": ROUTES,
        "start": str(START.date()),
        "cutoff_exclusive": str(CUTOFF.date()),
        "timezone": "Europe/Moscow",
        "files": verify_data(root)["files"],
    }
