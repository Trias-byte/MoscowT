"""34 fixed-origin features for the submitted 2025 CatBoost model."""

import numpy as np
import pandas as pd

from .data import ROUTES, START

SPARSE = [1, 2, 3, 4, 5, 6, 7, 10, 14, 21, 28, 42, 61]
KEYS = ["origin", "date", "route", "hour"]
CAL = [
    "route",
    "hour",
    "dow",
    "month",
    "is_day_off",
    "is_holiday",
    "is_working_weekend",
    "profile_dow",
    "year_sin",
    "year_cos",
    "hour_sin",
    "hour_cos",
    "horizon_days",
]
HISTORY = [
    f"{family}_{w}"
    for w in [7, 14, 28, 56]
    for family in ["profile", "route_hour", "day_mean"]
] + [
    "day_dow_28",
    "day_std_56",
    "trend_14",
    "network_trend",
    "profile_std_28",
    "profile_n_28",
    "zero_fraction_28",
    "morning_fraction_28",
    "evening_fraction_28",
]

FEATURES = CAL + HISTORY


class FeatureBuilder:
    def __init__(self, panel, calendar):
        self.dates = pd.DatetimeIndex(sorted(panel.date.unique()))
        if not self.dates.equals(pd.date_range(START, periods=len(self.dates))):
            raise ValueError("History must be continuous from 2025-01-01")
        expected = pd.MultiIndex.from_product(
            [self.dates, ROUTES, range(24)], names=["date", "route", "hour"]
        )
        indexed = panel.set_index(["date", "route", "hour"])
        if indexed.index.has_duplicates or len(indexed) != len(expected):
            raise ValueError("Expected a full, unique route-hour grid")
        values = indexed.reindex(expected).boardings.to_numpy(dtype=float)
        if not np.isfinite(values).all() or (values < 0).any():
            raise ValueError("Unknown observations must not silently become zero")
        self.values = values.reshape(len(self.dates), len(ROUTES), 24)
        self.cal = calendar.copy()
        if not pd.DatetimeIndex(self.cal.date).equals(
            pd.date_range(START, "2025-12-31")
        ):
            raise ValueError("Expected the complete 2025 calendar")
        self.snapshots = {}

    def day(self, date):
        value = pd.Timestamp(date)
        if value.tz is not None or value != value.normalize():
            raise ValueError("Use a Moscow service date YYYY-MM-DD at local midnight")
        return int((value - START).days)

    def snapshot(self, origin):
        if origin in self.snapshots:
            return self.snapshots[origin]
        if origin < 28 or origin > len(self.values):
            raise ValueError("Origin needs 28 completed historical days")
        past = self.values[:origin]
        hist_dow = self.cal.profile_dow.to_numpy()[:origin]
        snap = {}
        for w in [7, 14, 28, 56]:
            data = past[-w:]
            dows = hist_dow[-w:]
            hours = data.mean(axis=0)
            totals = data.sum(axis=2)
            snap[f"route_hour_{w}"] = np.broadcast_to(
                hours, (7, len(ROUTES), 24)
            ).copy()
            snap[f"day_mean_{w}"] = np.broadcast_to(
                totals.mean(axis=0)[None, :, None], (7, len(ROUTES), 24)
            ).copy()
            for stat in ["profile"] + (["median"] if w in [28, 56] else []):
                a = np.empty((7, len(ROUTES), 24))
                for d in range(7):
                    selected = data[dows == d]
                    a[d] = (
                        (
                            np.median(selected, axis=0)
                            if stat == "median"
                            else selected.mean(axis=0)
                        )
                        if len(selected)
                        else hours
                    )
                snap[f"{stat}_{w}"] = a
            if w == 28:
                for name in ["day_dow_28", "profile_std_28", "profile_n_28"]:
                    a = np.empty((7, len(ROUTES), 24))
                    for d in range(7):
                        selected = data[dows == d]
                        if name == "day_dow_28":
                            a[d] = (
                                selected.sum(axis=2).mean(axis=0)
                                if len(selected)
                                else totals.mean(axis=0)
                            )[:, None]
                        elif name == "profile_std_28":
                            a[d] = (
                                selected.std(axis=0)
                                if len(selected)
                                else data.std(axis=0)
                            )
                        else:
                            a[d] = len(selected)
                    snap[name] = a
        recent = past[-14:].sum(axis=(0, 2))
        previous = past[-28:-14].sum(axis=(0, 2))
        route_stats = {
            "trend_14": np.clip((recent + 1) / (previous + 1), 0.25, 4),
            "network_trend": np.repeat(
                np.clip((recent.sum() + 1) / (previous.sum() + 1), 0.25, 4), len(ROUTES)
            ),
            "day_std_56": past[-56:].sum(axis=2).std(axis=0),
            "zero_fraction_28": (past[-28:] == 0).mean(axis=(0, 2)),
            "morning_fraction_28": past[-28:, :, 7:10].sum(axis=(0, 2))
            / (past[-28:].sum(axis=(0, 2)) + 1),
            "evening_fraction_28": past[-28:, :, 16:20].sum(axis=(0, 2))
            / (past[-28:].sum(axis=(0, 2)) + 1),
        }
        for name, a in route_stats.items():
            snap[name] = np.broadcast_to(a[None, :, None], (7, len(ROUTES), 24)).copy()
        self.snapshots[origin] = snap
        return snap

    def build_pairs(self, pairs):
        pairs = np.asarray(pairs, dtype=int)
        origins, targets, horizons = pairs.T
        n = len(pairs)
        size = len(ROUTES) * 24
        routes = np.tile(np.repeat(np.array(ROUTES).astype(str), 24), n)
        hour = np.tile(np.arange(24), n * len(ROUTES))
        frame = pd.DataFrame(
            {
                "origin": START + pd.to_timedelta(np.repeat(origins, size), unit="D"),
                "date": START + pd.to_timedelta(np.repeat(targets, size), unit="D"),
                "route": routes,
                "hour": hour,
                "horizon_days": np.repeat(horizons, size),
                "hour_sin": np.sin(2 * np.pi * hour / 24),
                "hour_cos": np.cos(2 * np.pi * hour / 24),
            }
        )
        for col in [c for c in self.cal if c != "date"]:
            frame[col] = np.repeat(self.cal[col].to_numpy()[targets], size)
        for col in HISTORY + ["median_28", "median_56"]:
            frame[col] = np.concatenate(
                [
                    self.snapshot(int(o))[col][
                        int(self.cal.iloc[t].profile_dow)
                    ].ravel()
                    for o, t, _ in pairs
                ]
            )
        frame["history_end"] = frame.origin.to_numpy(
            dtype="datetime64[ns]"
        ) - np.timedelta64(1, "h")
        if targets.max() < len(self.values):
            frame["boardings"] = np.concatenate(
                [self.values[t].ravel() for t in targets]
            )
        for col in frame.select_dtypes("float"):
            frame[col] = frame[col].astype("float32")
        return frame

    def train(self, origin):
        cutoff = self.day(origin)
        if cutoff < 29 or cutoff > len(self.values):
            raise ValueError(
                "Training origin needs at least 29 completed days within the history"
            )
        pairs = [
            (o, o + h - 1, h)
            for o in range(28, cutoff, 14)
            for h in SPARSE
            if o + h - 1 < cutoff
        ]
        limit = min(500, len(pairs))
        if len(pairs) > limit:
            rng = np.random.default_rng(2026)
            pairs = [
                pairs[i] for i in sorted(rng.choice(len(pairs), limit, replace=False))
            ]
        frame = self.build_pairs(pairs)
        if (
            not (frame.date < pd.Timestamp(origin)).all()
            or not (frame.history_end < frame.origin).all()
        ):
            raise AssertionError("Future data entered training")
        return frame

    def forecast(self, origin):
        o = self.day(origin)
        if o < 28 or o > len(self.values) or o + 60 >= len(self.cal):
            raise ValueError(
                "Origin/horizon outside available history or 2025 calendar"
            )
        return self.build_pairs([(o, o + h - 1, h) for h in range(1, 62)])

    def zero_routes(self, origin):
        totals = self.values[: self.day(origin)].sum(axis=(0, 2))
        return [str(r) for r, total in zip(ROUTES, totals) if total == 0]
