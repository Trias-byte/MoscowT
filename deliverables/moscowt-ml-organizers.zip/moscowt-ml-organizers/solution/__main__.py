"""Run from the package root: python -m solution {audit,train,predict,backtest,verify}."""

import argparse
import json
from pathlib import Path

from .data import ROOT, audit, sha256, write_json
from .model import predict, train
from .pipeline import backtest, builder, export_submission


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("verify")
    audit_cli = commands.add_parser("audit")
    audit_cli.add_argument("--output", type=Path, default=Path("outputs/audit.json"))
    fit = commands.add_parser("train")
    fit.add_argument("--origin", default="2025-11-01")
    fit.add_argument("--output", type=Path, default=Path("outputs/retrained"))
    infer = commands.add_parser("predict")
    infer.add_argument("--models", type=Path, default=ROOT / "models")
    infer.add_argument("--output", type=Path, default=Path("outputs/submission.csv"))
    infer.add_argument("--require-reference", action="store_true")
    validation = commands.add_parser("backtest")
    validation.add_argument("--origin", default="2025-09-01")
    validation.add_argument(
        "--output", type=Path, default=Path("outputs/backtest-september")
    )
    for sub in (fit, infer, validation):
        sub.add_argument("--threads", type=int, choices=range(1, 5), default=4)
    args = parser.parse_args()
    if args.command == "verify":
        manifest = json.loads((ROOT / "SHA256SUMS.json").read_text(encoding="utf-8"))
        for name, checksum in manifest.items():
            if sha256(ROOT / name) != checksum:
                raise ValueError(f"Release file changed: {name}")
        result = {"verified_files": len(manifest), "status": "ok"}
    elif args.command == "audit":
        result = audit()
        write_json(args.output, result)
    elif args.command == "train":
        result = train(builder(), args.origin, args.output, args.threads)
    elif args.command == "predict":
        result = export_submission(
            predict(builder(), args.models, args.threads), args.output
        )
        if args.require_reference and not result["matches_reference"]:
            raise ValueError("Forecast differs from the submitted reference")
    else:
        result = backtest(args.origin, args.output, args.threads)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
