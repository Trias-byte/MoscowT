"""Standalone organizer release. No application imports or network calls."""
